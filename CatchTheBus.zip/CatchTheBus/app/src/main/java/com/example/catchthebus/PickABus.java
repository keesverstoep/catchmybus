package com.example.catchthebus;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;

public class PickABus extends AppCompatActivity {
    private RecyclerView busRecyclerView;
    private BusAdapter busAdapter;
    private RecyclerView.LayoutManager busLayout;
    public Person me;
    ArrayList<Bus> buses;
    Stop stop;

    TextView stopText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_a_bus);

        start();
    }

    public void start() {
        Intent i = getIntent();
        try {
            Stop stop = (Stop) i.getSerializableExtra("stop");
            this.stop = stop;
            stopText = findViewById(R.id.stopName);
            stopText.setText(stop.getStop());
            me = (Person) i.getSerializableExtra("me");
            buses = (ArrayList<Bus>) i.getSerializableExtra("buses");
            System.out.println(buses.size());
            doRecycler();
        } catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
            Bus dummyBus = new Bus();
            dummyBus.setLinePublicNumber("Error: No buses");
            dummyBus.set_destinationCode50("");
            dummyBus.setExpectedDepartureTime("");
            buses.add(dummyBus);
            doRecycler();
        }
    }

    public void doRecycler() {
        busRecyclerView = findViewById(R.id.recyclerViewBuses);
        busRecyclerView.setHasFixedSize(true);
        busLayout = new LinearLayoutManager(this);
        busAdapter = new BusAdapter(buses);
        busRecyclerView.setLayoutManager(busLayout);
        busRecyclerView.setAdapter(busAdapter);

        busAdapter.setOnItemClickListener(new BusAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) throws InterruptedException, IOException, JSONException {
                startBusChosenThread(position);
            }
        });
    }

    public void startBusChosenThread(int position) {
        BusChosenWork busChosenWork = new BusChosenWork(position);
        new Thread(busChosenWork).start();
    }

    public void stopStopChosenThread() {

    }

    class BusChosenWork implements Runnable {
        int position;

        BusChosenWork(int position) {
            this.position = position;
        }

        @Override
        public void run() {
            try {
                busChosen(position);
            } catch (IOException | InterruptedException | JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public void busChosen(int position) throws InterruptedException, JSONException, IOException {
        Bus bus = buses.get(position);
        Intent intent = new Intent(this, BusActivity.class);
        //queryAdapter.notifyItemChanged(position);
        intent.putExtra("me",me);
        intent.putExtra("stop", stop);
        intent.putExtra("bus",bus);
        startActivity(intent);
    }
}
