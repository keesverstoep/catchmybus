package com.example.catchthebus;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class StartHapticActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_haptic);
    }
}